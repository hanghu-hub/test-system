% clear; clc; close all;

tin1=0.002;     %恒流时间
tin2=0.02;      %阶跃切换时间
%% ================= Step 1：节点导纳矩阵 =================

Y=zeros(123,123);

% R1=0.5;R2=0.4;R3=0.4;R4=0.4;
R1=0.3;R2=0.2;R3=0.2;R4=0.3;    %线路阻值
Y_R1=1/R1;Y_R2=1/R2;Y_R3=1/R3;Y_R4=1/R4;


Y(10,123)=Y_R1;Y(122,123)=Y_R1;Y(121,122)=Y_R1;Y(117,121)=Y_R1;
Y(120,122)=Y_R1;Y(118,120)=Y_R1;Y(18,118)=Y_R1;Y(118,119)=Y_R1;
Y(88,119)=Y_R1;Y(87,88)=Y_R1;Y(86,87)=Y_R1;Y(85,86)=Y_R1;
Y(84,86)=Y_R1;Y(83,84)=Y_R1;Y(82,84)=Y_R1;Y(81,82)=Y_R1;
Y(80,82)=Y_R1;Y(79,80)=Y_R1;Y(78,80)=Y_R1;Y(20,78)=Y_R1;

Y(6,99)=Y_R2;Y(97,98)=Y_R2;Y(98,99)=Y_R2;Y(96,100)=Y_R2;Y(88,91)=Y_R2;
Y(97,100)=Y_R2;Y(96,97)=Y_R2;Y(100,101)=Y_R2;Y(101,102)=Y_R2;
Y(102,103)=Y_R2;Y(103,104)=Y_R2;Y(102,105)=Y_R2;Y(105,106)=Y_R2;
Y(106,107)=Y_R2;Y(7,107)=Y_R2;Y(105,108)=Y_R2;Y(108,109)=Y_R2;
Y(110,111)=Y_R2;Y(109,110)=Y_R2;Y(72,108)=Y_R2;Y(72,73)=Y_R2;
Y(73,112)=Y_R2;Y(112,113)=Y_R2;Y(8,113)=Y_R2;Y(72,91)=Y_R2;
Y(91,114)=Y_R2;Y(114,115)=Y_R2;Y(115,116)=Y_R2;Y(9,116)=Y_R2;

Y(71,72)=Y_R3;Y(70,71)=Y_R3;Y(69,70)=Y_R3;Y(69,92)=Y_R3;
Y(92,93)=Y_R3;Y(93,94)=Y_R3;Y(94,95)=Y_R3;Y(13,95)=Y_R3;
Y(69,89)=Y_R3;Y(89,90)=Y_R3;Y(68,69)=Y_R3;Y(68,76)=Y_R3;
Y(67,68)=Y_R3;Y(17,67)=Y_R3;Y(57,74)=Y_R3;Y(74,75)=Y_R3;
Y(75,76)=Y_R3;Y(76,77)=Y_R3;Y(19,77)=Y_R3;Y(64,65)=Y_R3;
Y(65,66)=Y_R3;Y(15,66)=Y_R3;Y(45,65)=Y_R3;Y(42,45)=Y_R3;
Y(14,42)=Y_R3;Y(40,42)=Y_R3;Y(40,41)=Y_R3;Y(37,40)=Y_R3;
Y(37,38)=Y_R3;Y(38,39)=Y_R3;Y(31,37)=Y_R3;Y(30,31)=Y_R3;
Y(31,32)=Y_R3;Y(32,33)=Y_R3;Y(12,33)=Y_R3;Y(44,45)=Y_R3;

Y(1,23)=Y_R4;Y(23,24)=Y_R4;Y(21,22)=Y_R4;Y(22,24)=Y_R4;
Y(24,25)=Y_R4;Y(25,26)=Y_R4;Y(26,29)=Y_R4;Y(28,29)=Y_R4;
Y(27,28)=Y_R4;Y(11,27)=Y_R4;Y(29,34)=Y_R4;Y(2,34)=Y_R4;
Y(34,35)=Y_R4;Y(35,36)=Y_R4;Y(35,44)=Y_R4;Y(43,44)=Y_R4;
Y(16,43)=Y_R4;Y(44,57)=Y_R4;Y(57,58)=Y_R4;Y(58,59)=Y_R4;
Y(4,59)=Y_R4;Y(59,63)=Y_R4;Y(55,57)=Y_R4;Y(55,56)=Y_R4;
Y(51,55)=Y_R4;Y(48,51)=Y_R4;Y(47,48)=Y_R4;Y(46,47)=Y_R4;
Y(3,46)=Y_R4;Y(46,49)=Y_R4;Y(54,55)=Y_R4;Y(53,54)=Y_R4;
Y(50,53)=Y_R4;Y(52,53)=Y_R4;Y(53,60)=Y_R4;Y(5,60)=Y_R4;
Y(60,61)=Y_R4;Y(61,62)=Y_R4;


Y=Y+Y';
Y=diag(Y*ones(123,1))-Y;

% disp('Y=')
% disp(Y)

Y_SS=Y(1:10,1:10);Y_SL=Y(1:10,11:123);Y_LS=Y(11:123,1:10);Y_LL=Y(11:123,11:123); 

%% ================= Step 2：系统参数 =================

syms Ki K u_ref R_L        
syms L [10,1] real         
syms C [10,1] real 

params.Ki    = 300;  %积分增益系数                
params.K     = 1;                 
params.L     = 8e-4 * ones(10,1);   
params.C     = 2e-4 * ones(10,1);   
params.u_ref = 650;  
PL=[3e3*ones(10,1);2.5e3*ones(45,1);2.5e3*ones(25,1);3e3*ones(33,1)]; 

%% ================ Step 3：牛顿法求解UL =====================
% 求解Yeq和alpha
Kinv = eye(10)/params.K;
Yeq=Y_LL-Y_LS*(Y_SS+Kinv)^(-1)*Y_SL;

Vstar = params.u_ref * ones(10,1);
alpha = Y_LS * (Y_SS + Kinv)^(-1) * Kinv * Vstar;

tol = 1e-6;
maxIter = 100;
u = params.u_ref * ones(113,1);
p = -PL;

for iter = 1:maxIter
    UL = diag(u);
    F = UL * (Yeq * u + alpha) - p;
    J = diag(Yeq * u + alpha) + UL * Yeq;
    du = -J\F;
    u = u + du;
    
    if norm(du, inf) < tol
        fprintf('牛顿迭代在 %d 次收敛。\n', iter);
        break;
    end
end

disp('---- 计算结果 ----');
Vin = ones(123,1);
for i = 1:113
    load_node = 10+i;  % 负载节点11~123
    Vin(load_node) = u(i);
    fprintf('V_CPL%d = %.4f V\n', load_node, u(i));
end
Vin_ = Vin(11:123);

%% ================ Step 4：列雅可比矩阵 =====================
% 等效CPL阻值
params.R_L_vec = zeros(113,1);
params.R_L_vec = Vin_.^2 ./ PL; 

% 等效导纳
Y_LL_RL = Y_LL - diag(params.R_L_vec)^(-1); 
Y_LL_RL_inv = (Y_LL_RL)^(-1);
Y_SYS_num = Y_SS - Y_SL * Y_LL_RL_inv * Y_LS;
% disp('数值 Y_SYS = ');
% disp(Y_SYS_num);

% 状态变量
syms i_L [10,1] real       
syms u_S [10,1] real      
syms u_ [10,1] real            

x = [i_L; u_S; u_];

% 状态方程
di_L = (- K*i_L - u_S +Ki*u_) ./ L;
du_S = (i_L - Y_SYS_num*u_S) ./ C;  
du_  = - K*i_L - u_S;

dx = [di_L; du_S; du_];

% 雅可比矩阵
J = jacobian(dx, x);
disp(' ');
disp('雅可比矩阵 J = ');
disp(J);

%% ================= Step 5：求解雅可比矩阵 =================

% 计算雅可比矩阵
sym_vars = [Ki, K, L(:)', C(:)', u_ref];
num_vars = [params.Ki, params.K, params.L(:)', params.C(:)', params.u_ref];

J_num = subs(J, sym_vars, num_vars);
J_num = double(J_num);

disp('雅可比矩阵 = ');
disp(J_num);

% 特征值
eig_vals = eig(J_num);
disp('系统特征值 = ');
disp(eig_vals);

% 稳定性判断
max_real_part = max(real(eig_vals));
if max_real_part < 0
    fprintf('系统稳定，最大实部 = %.4f\n', max_real_part);
elseif max_real_part == 0
    fprintf('系统临界稳定\n');
else
    fprintf('系统不稳定，最大实部 = %.4f\n', max_real_part);
end

%% ================= Step 6：绘制根轨迹图 =================
% 定义可变参数范围
Ki_range = linspace(1, 800, 20);  % Ki从0到2000，取200个点
eig_trajectory = zeros(length(Ki_range), length(eig_vals));  % 存储特征值轨迹

% 遍历Ki的每个取值，计算对应的特征值
fprintf('正在计算根轨迹数据...\n');
for idx = 1:length(Ki_range)
    % 更新Ki参数
    params_temp = params;
    params_temp.Ki = Ki_range(idx);
    
    % 计算雅可比矩阵
    num_vars_temp = [params_temp.Ki, params_temp.K, params_temp.L(:)', params_temp.C(:)', params_temp.u_ref];
    J_temp = subs(J, sym_vars, num_vars_temp);
    J_temp = double(J_temp);
    
    % 计算特征值并存储
    eig_temp = eig(J_temp);
    eig_trajectory(idx, :) = eig_temp;
end

% 绘制根轨迹图
figure('Color','white','Position',[10,10,650,450]);
hold on; 
grid on; 
box on;


for eig_idx = 1:length(eig_vals)
    plot(real(eig_trajectory(:, eig_idx)), imag(eig_trajectory(:, eig_idx)), '*', 'MarkerSize', 8, 'LineWidth', 1, 'DisplayName', sprintf('特征根 %d', eig_idx));
end


xlim([min(real(eig_trajectory(:)))-1000, max(real(eig_trajectory(:)))+1200]);
ylim([min(imag(eig_trajectory(:)))-1300, max(imag(eig_trajectory(:)))+1300]);
set(gca,'FontSize',10);

fprintf('根轨迹图绘制完成！\n');