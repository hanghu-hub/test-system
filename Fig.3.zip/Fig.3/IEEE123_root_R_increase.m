
clear; clc; close all;

tin1 = 0.002;     % 恒流时间
tin2 = 0.02;      % 阶跃切换时间

%% ================= Step 1：节点导纳矩阵 =================
Y = zeros(123,123);

R1 = 0.3; R2 = 0.2; R3 = 0.2; R4 = 0.3;
Y_R1 = 1/R1; Y_R2 = 1/R2;
Y_R3 = 1/R3; Y_R4 = 1/R4;

Y(10,123)=Y_R1; Y(122,123)=Y_R1; Y(121,122)=Y_R1; Y(117,121)=Y_R1;
Y(120,122)=Y_R1; Y(118,120)=Y_R1; Y(18,118)=Y_R1; Y(118,119)=Y_R1;
Y(88,119)=Y_R1; Y(87,88)=Y_R1; Y(86,87)=Y_R1; Y(85,86)=Y_R1;
Y(84,86)=Y_R1; Y(83,84)=Y_R1; Y(82,84)=Y_R1; Y(81,82)=Y_R1;
Y(80,82)=Y_R1; Y(79,80)=Y_R1; Y(78,80)=Y_R1; Y(20,78)=Y_R1;

Y(6,99)=Y_R2; Y(97,98)=Y_R2; Y(98,99)=Y_R2; Y(96,100)=Y_R2;
Y(88,91)=Y_R2; Y(97,100)=Y_R2; Y(96,97)=Y_R2; Y(100,101)=Y_R2;
Y(101,102)=Y_R2; Y(102,103)=Y_R2; Y(103,104)=Y_R2; Y(102,105)=Y_R2;
Y(105,106)=Y_R2; Y(106,107)=Y_R2; Y(7,107)=Y_R2; Y(105,108)=Y_R2;
Y(108,109)=Y_R2; Y(110,111)=Y_R2; Y(109,110)=Y_R2; Y(72,108)=Y_R2;
Y(72,73)=Y_R2; Y(73,112)=Y_R2; Y(112,113)=Y_R2; Y(8,113)=Y_R2;
Y(72,91)=Y_R2; Y(91,114)=Y_R2; Y(114,115)=Y_R2; Y(115,116)=Y_R2;
Y(9,116)=Y_R2;

Y(71,72)=Y_R3; Y(70,71)=Y_R3; Y(69,70)=Y_R3; Y(69,92)=Y_R3;
Y(92,93)=Y_R3; Y(93,94)=Y_R3; Y(94,95)=Y_R3; Y(13,95)=Y_R3;
Y(69,89)=Y_R3; Y(89,90)=Y_R3; Y(68,69)=Y_R3; Y(68,76)=Y_R3;
Y(67,68)=Y_R3; Y(17,67)=Y_R3; Y(57,74)=Y_R3; Y(74,75)=Y_R3;
Y(75,76)=Y_R3; Y(76,77)=Y_R3; Y(19,77)=Y_R3; Y(64,65)=Y_R3;
Y(65,66)=Y_R3; Y(15,66)=Y_R3; Y(45,65)=Y_R3; Y(42,45)=Y_R3;
Y(14,42)=Y_R3; Y(40,42)=Y_R3; Y(40,41)=Y_R3; Y(37,40)=Y_R3;
Y(37,38)=Y_R3; Y(38,39)=Y_R3; Y(31,37)=Y_R3; Y(30,31)=Y_R3;
Y(31,32)=Y_R3; Y(32,33)=Y_R3; Y(12,33)=Y_R3; Y(44,45)=Y_R3;

Y(1,23)=Y_R4; Y(23,24)=Y_R4; Y(21,22)=Y_R4; Y(22,24)=Y_R4;
Y(24,25)=Y_R4; Y(25,26)=Y_R4; Y(26,29)=Y_R4; Y(28,29)=Y_R4;
Y(27,28)=Y_R4; Y(11,27)=Y_R4; Y(29,34)=Y_R4; Y(2,34)=Y_R4;
Y(34,35)=Y_R4; Y(35,36)=Y_R4; Y(35,44)=Y_R4; Y(43,44)=Y_R4;
Y(16,43)=Y_R4; Y(44,57)=Y_R4; Y(57,58)=Y_R4; Y(58,59)=Y_R4;
Y(4,59)=Y_R4; Y(59,63)=Y_R4; Y(55,57)=Y_R4; Y(55,56)=Y_R4;
Y(51,55)=Y_R4; Y(48,51)=Y_R4; Y(47,48)=Y_R4; Y(46,47)=Y_R4;
Y(3,46)=Y_R4; Y(46,49)=Y_R4; Y(54,55)=Y_R4; Y(53,54)=Y_R4;
Y(50,53)=Y_R4; Y(52,53)=Y_R4; Y(53,60)=Y_R4; Y(5,60)=Y_R4;
Y(60,61)=Y_R4; Y(61,62)=Y_R4;

Y = Y + Y';
Y = diag(Y*ones(123,1)) - Y;

Y_SS = Y(1:10,1:10);
Y_SL = Y(1:10,11:123);
Y_LS = Y(11:123,1:10);
Y_LL = Y(11:123,11:123);

%% ================= Step 2：系统参数 =================
params.Ki = 300;
params.K = 1;
params.L = 5e-4*ones(10,1);
params.C = 10e-4*ones(10,1);
params.u_ref = 650;

PL = [3e3*ones(10,1);
      2.5e3*ones(45,1);
      2.5e3*ones(25,1);
      3e3*ones(33,1)];

p = -PL;

%% ================= Step 3：K扫描设置 =================
% K_min = 0.1;
% K_max_scan = 2.5;
% dK = 0.0002;
% 
% % 牛顿法参数
tol = 1e-6;
maxIter = 100;
% 
% % 稳定边界精度
K_tol = 1e-5;
stable_tol = 1e-7;
% 
% K_range = K_min:dK:K_max_scan;
K_range = [0.1:0.1:2.13, 2.1302:0.0005:2.15];
nK = length(K_range);

% 每个K的计算结果
max_real_all = nan(nK,1);
equilibrium_ok = false(nK,1);
eig_all = cell(nK,1);
U_all = cell(nK,1);

% 采用连续延拓：上一K的平衡点作为下一K的初值
u_init = params.u_ref*ones(113,1);

fprintf('\n========== 开始逐K重新求解平衡点 ==========\n');

%% ================= Step 4：逐K求平衡点和特征值 =================
for idx = 1:nK

    K_now = K_range(idx);

    % ---------- 4.1 重新计算等效潮流方程 ----------
    Kinv = eye(10)/K_now;

    Yeq = Y_LL - Y_LS*((Y_SS + Kinv)\Y_SL);
    alpha = Y_LS*((Y_SS + Kinv)\(Kinv*(params.u_ref*ones(10,1))));

    % ---------- 4.2 牛顿法重新求平衡点 ----------
    u = u_init;
    converged = false;

    for iter = 1:maxIter

        F = u.*(Yeq*u + alpha) - p;
        J_pf = diag(Yeq*u + alpha) + diag(u)*Yeq;

        if any(~isfinite(F)) || any(~isfinite(J_pf(:)))
            break;
        end

        if rcond(J_pf) < 1e-14
            break;
        end

        du = -J_pf\F;

        % 保留正电压解，避免牛顿迭代直接进入负电压区域
        step = 1;
        while step > 1/1024 && any(u + step*du <= 0)
            step = step/2;
        end

        if step <= 1/1024
            break;
        end

        u = u + step*du;

        if norm(u.*(Yeq*u + alpha)-p,inf) < tol ...
                && norm(step*du,inf) < 1e-5
            converged = true;
            break;
        end
    end

    % 最终残差检查
    F_final = u.*(Yeq*u + alpha)-p;

    if ~converged && all(isfinite(u)) ...
            && norm(F_final,inf) < tol
        converged = true;
    end

    if ~converged || any(u <= 0) || any(~isfinite(u))
        fprintf('K = %.5f：潮流未收敛或无有效正电压解，停止扫描。\n',K_now);
        break;
    end

    equilibrium_ok(idx) = true;
    U_all{idx} = u;
    u_init = u;

    % ---------- 4.3 根据当前平衡点更新负载等效阻值 ----------
    Vin = ones(123,1);
    Vin(11:123) = u;

    Vin_load = Vin(11:123);
    R_L_vec = Vin_load.^2./PL;

    Y_LL_RL = Y_LL - diag(1./R_L_vec);

    % 用线性方程求解，避免显式求逆
    Y_SYS_num = Y_SS - Y_SL*(Y_LL_RL\Y_LS);

    % ---------- 4.4 重新构造当前K对应的雅可比矩阵 ----------
    L = params.L;
    C = params.C;
    Ki = params.Ki;

    A11 = diag(-K_now./L);
    A12 = diag(-1./L);
    A13 = diag(Ki./L);

    A21 = diag(1./C);
    A22 = -diag(1./C)*Y_SYS_num;
    A23 = zeros(10,10);

    A31 = -K_now*eye(10);
    A32 = -eye(10);
    A33 = zeros(10,10);

    J_num = [A11 A12 A13;
             A21 A22 A23;
             A31 A32 A33];

    % ---------- 4.5 当前平衡点的特征值 ----------
    eig_temp = eig(J_num);
    eig_all{idx} = eig_temp;
    max_real_all(idx) = max(real(eig_temp));

    fprintf(['K = %.5f | 牛顿迭代 = %3d | 残差 = %.3e | ' ...
             '最大实部 = %+.8e\n'], ...
             K_now,iter,norm(F_final,inf),max_real_all(idx));

end

%% ================= Step 5：寻找稳定上界 =================
valid_idx = find(equilibrium_ok);

if isempty(valid_idx)
    error('扫描区间内没有成功求得平衡点，请检查潮流方程和初值。');
end

% 找到第一个不稳定点
first_unstable = find(max_real_all(valid_idx) >= -stable_tol,1,'first');

if isempty(first_unstable)
    fprintf('\n扫描到的K范围内未发现稳定边界。\n');
    fprintf('已计算的最大K = %.6f\n',K_range(valid_idx(end)));
    K_upper = NaN;

elseif first_unstable == 1
    fprintf('\n最小扫描K处已经达到或超过稳定边界。\n');
    fprintf('K = %.6f，最大实部 = %.8e\n', ...
        K_range(valid_idx(1)),max_real_all(valid_idx(1)));
    K_upper = NaN;

else
    % 相邻的稳定点与非稳定点
    idx_stable = valid_idx(first_unstable-1);
    idx_unstable = valid_idx(first_unstable);

    Ka = K_range(idx_stable);
    Kb = K_range(idx_unstable);
    fa = max_real_all(idx_stable);
    fb = max_real_all(idx_unstable);

    if fa >= 0 || fb < 0
        fprintf('\n当前相邻点未形成明确的稳定到不稳定穿越。\n');
        K_upper = NaN;
    else
        fprintf('\n========== 开始二分细化稳定边界 ==========\n');

        % 二分过程中，沿用较小K端的平衡点作初值
        ua = U_all{idx_stable};

        while (Kb-Ka) > K_tol

            Km = (Ka+Kb)/2;

            Kinv = eye(10)/Km;
            Yeq_m = Y_LL - Y_LS*((Y_SS+Kinv)\Y_SL);
            alpha_m = Y_LS*((Y_SS+Kinv)\ ...
                (Kinv*(params.u_ref*ones(10,1))));

            um = ua;
            conv_m = false;

            for iter_m = 1:maxIter
                Fm = um.*(Yeq_m*um+alpha_m)-p;
                Jm_pf = diag(Yeq_m*um+alpha_m)+diag(um)*Yeq_m;

                if any(~isfinite(Fm)) || any(~isfinite(Jm_pf(:))) ...
                        || rcond(Jm_pf)<1e-14
                    break;
                end

                dum = -Jm_pf\Fm;

                step = 1;
                while step > 1/1024 && any(um+step*dum<=0)
                    step = step/2;
                end

                if step<=1/1024
                    break;
                end

                um = um+step*dum;

                if norm(um.*(Yeq_m*um+alpha_m)-p,inf)<tol ...
                        && norm(step*dum,inf)<1e-5
                    conv_m = true;
                    break;
                end
            end

            Fm = um.*(Yeq_m*um+alpha_m)-p;

            if ~conv_m && all(isfinite(um)) ...
                    && norm(Fm,inf)<tol
                conv_m = true;
            end

            if ~conv_m || any(um<=0) || any(~isfinite(um))
                fprintf('K = %.8f：二分点潮流未收敛，不能直接判定稳定边界。\n',Km);
                Kb = Km;
                continue;
            end

            Vin_m = ones(123,1);
            Vin_m(11:123) = um;
            RL_m = Vin_m(11:123).^2./PL;

            Y_LL_RL_m = Y_LL-diag(1./RL_m);
            Y_SYS_m = Y_SS-Y_SL*(Y_LL_RL_m\Y_LS);

            A11 = diag(-Km./params.L);
            A12 = diag(-1./params.L);
            A13 = diag(params.Ki./params.L);
            A21 = diag(1./params.C);
            A22 = -diag(1./params.C)*Y_SYS_m;
            A23 = zeros(10,10);
            A31 = -Km*eye(10);
            A32 = -eye(10);
            A33 = zeros(10,10);

            Jm = [A11 A12 A13;
                  A21 A22 A23;
                  A31 A32 A33];

            em = eig(Jm);
            fm = max(real(em));

            fprintf('K = %.8f | 最大实部 = %+.8e\n',Km,fm);

            if fm < 0
                Ka = Km;
                fa = fm;
                ua = um;
            else
                Kb = Km;
                fb = fm;
            end
        end

        K_upper = (Ka+Kb)/2;

        fprintf('\n========== 稳定上界搜索结果 ==========\n');
        fprintf('稳定侧 K = %.8f，最大实部 = %+.8e\n',Ka,fa);
        fprintf('不稳定侧 K = %.8f，最大实部 = %+.8e\n',Kb,fb);
        fprintf('估计稳定上界 K_upper = %.8f\n',K_upper);
        fprintf('K区间误差不超过 %.3e\n',K_tol);
    end
end

%% ================= Step 6：绘制根轨迹散点图 =================
figure('Color','white','Position',[10,10,750,520]);
hold on; box on; grid on;

for idx = valid_idx(:)'
    ev = eig_all{idx};
    % scatter(real(ev),imag(ev),12,'filled');
    plot(real(ev),imag(ev),'*','MarkerSize',7,'LineWidth', 0.8);

end

xline(0,'k--','LineWidth',1.2);
yline(0,'k:');

xlabel('实部');
ylabel('虚部');
title('每个K重新求平衡点后的系统特征值分布');

set(gca,'FontSize',11);
hold off;

%% ================= Step 7：最大实部随K变化 =================
figure('Color','white','Position',[50,50,750,450]);
hold on; box on; grid on;

plot(K_range(valid_idx),max_real_all(valid_idx), ...
    'b.-','LineWidth',1.2,'MarkerSize',12);

yline(0,'r--','LineWidth',1.2);

if isfinite(K_upper)
    xline(K_upper,'k--','LineWidth',1.2);
    text(K_upper,0,sprintf('  K_{upper}=%.6f',K_upper), ...
        'VerticalAlignment','bottom');
end

xlabel('K');
ylabel('最大特征值实部');
title('稳定性判据与K的关系');
set(gca,'FontSize',11);
hold off;

fprintf('\n计算结束。\n');
