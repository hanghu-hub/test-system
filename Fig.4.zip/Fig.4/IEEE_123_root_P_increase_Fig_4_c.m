clear; clc; close all;
%% 1. Network admittance matrix
Y=zeros(123,123);

R1=0.3;R2=0.2;R3=0.2;R4=0.3;    % Line resistances
Y_R1=1/R1;Y_R2=1/R2;Y_R3=1/R3;Y_R4=1/R4;

Y(10,123)=Y_R1;Y(122,123)=Y_R1;Y(121,122)=Y_R1;Y(117,121)=Y_R1;
Y(120,122)=Y_R1;Y(118,120)=Y_R1;Y(18,118)=Y_R1;Y(118,119)=Y_R1;
Y(88,119)=Y_R1;Y(87,88)=Y_R1;Y(86,87)=Y_R1;Y(85,86)=Y_R1;
Y(84,86)=Y_R1;Y(83,84)=Y_R1;Y(82,84)=Y_R1;Y(81,82)=Y_R1;
Y(80,82)=Y_R1;Y(79,80)=Y_R1;Y(78,80)=Y_R1;Y(20,78)=Y_R1;

Y(6,99)=Y_R2;Y(97,98)=Y_R2;Y(98,99)=Y_R2;Y(96,100)=Y_R2;Y(88,91)=Y_R2;
Y(97,100)=Y_R2;Y(96,97)=Y_R2;Y(100,101)=Y_R2;Y(101,102)=Y_R2;
Y(102,103)=Y_R2;Y(103,104)=Y_R2;Y(102,105)=Y_R2;Y(105,106)=Y_R2;
Y(106,107)=Y_R2;Y(7,107)=Y_R2;Y(105,108)=Y_R2;Y(108,109)=Y_R2;
Y(110,111)=Y_R2;Y(109,110)=Y_R2;Y(72,108)=Y_R2;Y(72,73)=Y_R2;
Y(73,112)=Y_R2;Y(112,113)=Y_R2;Y(8,113)=Y_R2;Y(72,91)=Y_R2;
Y(91,114)=Y_R2;Y(114,115)=Y_R2;Y(115,116)=Y_R2;Y(9,116)=Y_R2;

Y(71,72)=Y_R3;Y(70,71)=Y_R3;Y(69,70)=Y_R3;Y(69,92)=Y_R3;
Y(92,93)=Y_R3;Y(93,94)=Y_R3;Y(94,95)=Y_R3;Y(13,95)=Y_R3;
Y(69,89)=Y_R3;Y(89,90)=Y_R3;Y(68,69)=Y_R3;Y(68,76)=Y_R3;
Y(67,68)=Y_R3;Y(17,67)=Y_R3;Y(57,74)=Y_R3;Y(74,75)=Y_R3;
Y(75,76)=Y_R3;Y(76,77)=Y_R3;Y(19,77)=Y_R3;Y(64,65)=Y_R3;
Y(65,66)=Y_R3;Y(15,66)=Y_R3;Y(45,65)=Y_R3;Y(42,45)=Y_R3;
Y(14,42)=Y_R3;Y(40,42)=Y_R3;Y(40,41)=Y_R3;Y(37,40)=Y_R3;
Y(37,38)=Y_R3;Y(38,39)=Y_R3;Y(31,37)=Y_R3;Y(30,31)=Y_R3;
Y(31,32)=Y_R3;Y(32,33)=Y_R3;Y(12,33)=Y_R3;Y(44,45)=Y_R3;

Y(1,23)=Y_R4;Y(23,24)=Y_R4;Y(21,22)=Y_R4;Y(22,24)=Y_R4;
Y(24,25)=Y_R4;Y(25,26)=Y_R4;Y(26,29)=Y_R4;Y(28,29)=Y_R4;
Y(27,28)=Y_R4;Y(11,27)=Y_R4;Y(29,34)=Y_R4;Y(2,34)=Y_R4;
Y(34,35)=Y_R4;Y(35,36)=Y_R4;Y(35,44)=Y_R4;Y(43,44)=Y_R4;
Y(16,43)=Y_R4;Y(44,57)=Y_R4;Y(57,58)=Y_R4;Y(58,59)=Y_R4;
Y(4,59)=Y_R4;Y(59,63)=Y_R4;Y(55,57)=Y_R4;Y(55,56)=Y_R4;
Y(51,55)=Y_R4;Y(48,51)=Y_R4;Y(47,48)=Y_R4;Y(46,47)=Y_R4;
Y(3,46)=Y_R4;Y(46,49)=Y_R4;Y(54,55)=Y_R4;Y(53,54)=Y_R4;
Y(50,53)=Y_R4;Y(52,53)=Y_R4;Y(53,60)=Y_R4;Y(5,60)=Y_R4;
Y(60,61)=Y_R4;Y(61,62)=Y_R4;

Y=Y+Y';
Y=diag(Y*ones(123,1))-Y;
Y_SS = Y(1:10,1:10);
Y_SL = Y(1:10,11:123);
Y_LS = Y(11:123,1:10);
Y_LL = Y(11:123,11:123);

%% 2. Controller parameters and load-increasing settings
params.Ki = 300;
params.K = 1;
params.L = 0.0005*ones(10,1);
params.C = 0.001*ones(10,1);
params.u_ref = 650;
PL0 = [3e3*ones(10,1); 2.5e3*ones(70,1); 3e3*ones(33,1)];
Pbase_W = sum(PL0);
P_target_kW = Inf;       % Total load target [kW]; Inf means determined by the fold upper limit
DeltaP_kW = 5;           % Maximum load increase per step [kW]
foldRelativeGap = 1e-6;
cfg.tolNewton = 1e-12;
cfg.minRcondB = 1e-12;
cfg.originAbsTol = 1e-6;
cfg.positiveRealTol = 0;
cfg.nearOriginGuard = 1e-2;
cfg.minStep_W = 1e-4;
cfg.maxPoints = 5000;
cfg.maxTrials = 60;
cfg.nearFoldFactor = 0.25;

Kinv = eye(10)/params.K;
Vstar = params.u_ref*ones(10,1);
Asrc = Y_SS + Kinv;
net.Yss = Y_SS; net.Ysl = Y_SL;
net.Yls = Y_LS; net.Yll = Y_LL;
net.Yeq = Y_LL - Y_LS*(Asrc\Y_SL);
net.a = Y_LS*(Asrc\(Kinv*Vstar))/params.u_ref;
net.q = PL0/params.u_ref^2;
net.PL0 = PL0;
net.n = numel(PL0);
n = net.n;

%% 3. Compute the power limit of the high-voltage branch
v_start = -(net.Yeq\net.a);
lambdaUpper = sum(Vstar.^2)/(4*params.K*Pbase_W);
coarseStep = 0.02;
v_seed = v_start;
lambda_seed = 0;
for lambda_try = coarseStep:coarseStep:(lambdaUpper + coarseStep)
    [v_try,ok] = damped_newton(@(v) fixed_power(v,lambda_try,net),v_seed,n,[],cfg.tolNewton);
    if ~ok
        break;
    end
    [~,S_try] = fixed_power(v_try,lambda_try,net);
    [~,flag] = chol((S_try+S_try.')/2);
    if flag ~= 0
        break;
    end
    v_seed = v_try;
    lambda_seed = lambda_try;
end

% Fold point: h=0, S*w=0, w.'*w=1.
[~,S_seed] = fixed_power(v_seed,lambda_seed,net);
[W,D] = eig((S_seed+S_seed.')/2);
[~,iw] = min(abs(diag(D)));
z_seed = [v_seed;lambda_seed;W(:,iw)];
[z_fold,ok] = damped_newton(@(z) fold_equations(z,net),z_seed,n,n+1,cfg.tolNewton);
if ~ok
    error('Fold point solution did not converge.');
end
lambda_c = z_fold(n+1);
Pcrit_W = lambda_c*Pbase_W;
Pstop_W = min(1e3*P_target_kW,(1-foldRelativeGap)*Pcrit_W);
lambda_target = Pstop_W/Pbase_W;
fprintf('\nBase total CPL power: %.6f kW\n',Pbase_W/1e3);
fprintf('Computed critical multiplier: %.12f\n',lambda_c);
fprintf('Computed critical total power: %.9f kW\n',Pcrit_W/1e3);

%% 4. Increase load along the high-voltage branch and compute eigenvalues
lambda_range = nan(cfg.maxPoints,1);
eig_trajectory = complex(nan(cfg.maxPoints,30));
[st,ok] = inspect_point(v_start,0,params,net,cfg,[]);
if ~ok
    error('Initial operating point is invalid.');
end
nPoint = 1;
lambda_range(1) = 0;
eig_trajectory(1,:) = st.roots;
v_previous = v_start;
lambda_previous = 0;
dlambdaMax = DeltaP_kW*1e3/Pbase_W;
dlambdaNext = dlambdaMax;
dlambdaMin = cfg.minStep_W/Pbase_W;
while lambda_previous < lambda_target
    if nPoint >= cfg.maxPoints
        break;
    end
    remaining = lambda_target-lambda_previous;
    if remaining*Pbase_W <= max(1e-7,1e-12*Pstop_W)
        break;
    end
    dlamTry = min([dlambdaNext,remaining,cfg.nearFoldFactor*(lambda_c-lambda_previous)]);
    accepted = false;
    % Reuse the Jacobian from the previous operating point, then correct with Newton's method after prediction.
    tangent = -(st.S\(net.q./v_previous));
    for trial = 1:cfg.maxTrials
        lambda_try = lambda_previous+dlamTry;
        if lambda_try <= lambda_previous || lambda_try >= lambda_c
            break;
        end
        v_guess = v_previous+dlamTry*tangent;
        if any(v_guess <= 1e-6) || any(~isfinite(v_guess))
            v_guess = v_previous;
        end
        [v_try,okNewton] = damped_newton(@(v) fixed_power(v,lambda_try,net),v_guess,n,[],cfg.tolNewton);
        if okNewton
            [st_try,okPoint] = inspect_point(v_try,lambda_try,params,net,cfg,st.roots);
            if okPoint
                accepted = true;
                break;
            end
        end
        dlamTry = dlamTry/2;
        if dlamTry < dlambdaMin
            break;
        end
    end
    if ~accepted
        break;
    end
    st = st_try;
    nPoint = nPoint+1;
    lambda_range(nPoint) = lambda_try;
    eig_trajectory(nPoint,:) = st.roots;
    v_previous = v_try;
    lambda_previous = lambda_try;
    if st.reachedOrigin
        break;
    end
    if st.maxReal > -cfg.nearOriginGuard
        dlambdaNext = min(dlambdaMax,max(dlambdaMin,0.25*dlamTry));
    else
        dlambdaNext = min(dlambdaMax,1.3*dlamTry);
    end
end
lambda_range = lambda_range(1:nPoint);
eig_trajectory = eig_trajectory(1:nPoint,:);
Ptotal_kW = lambda_range*Pbase_W/1e3;

%% 5. Plot root locus
figure('Color','white','Position',[10,10,650,450]);
hold on; grid on; box on;
for eig_idx = 1:30
    plot(real(eig_trajectory(:,eig_idx)),imag(eig_trajectory(:,eig_idx)), ...
        '*','MarkerSize',5,'LineWidth',1);
end
xline(0,'--','HandleVisibility','off');
yline(0,':','HandleVisibility','off');
xlabel('Real part'); ylabel('Imaginary part');
title(sprintf('Power: P = 0 to %.3f kW',Ptotal_kW(end)));
set(gca,'FontSize',10);

%% Functions
function [h,S] = fixed_power(v,lambda,net)
    h = net.Yeq*v+net.a+lambda*net.q./v;
    S = net.Yeq-diag(lambda*net.q./v.^2);
end

function [F,J] = fold_equations(z,net)
    n = net.n;
    v = z(1:n); lambda = z(n+1); w = z(n+2:end);
    [h,S] = fixed_power(v,lambda,net);
    F = [h;S*w;(w.'*w-1)/2];
    J = [S,net.q./v,zeros(n); ...
         diag(2*lambda*net.q.*w./v.^3),-net.q.*w./v.^2,S; ...
         zeros(1,n),0,w.'];
end

function [x,ok] = damped_newton(fun,x,nVoltage,lambdaIndex,tol)
    ok = false;
    for it = 1:60
        [F,J] = fun(x);
        residual = norm(F,inf);
        if ~all(isfinite(F)) || ~all(isfinite(x)), return; end
        if residual <= tol
            ok = true;
            return;
        end
        if rcond(J) < 1e-15, return; end
        dx = -(J\F);
        step = 1;
        accepted = false;
        for bt = 1:40
            xt = x+step*dx;
            positive = all(xt(1:nVoltage)>1e-6);
            if ~isempty(lambdaIndex)
                positive = positive && xt(lambdaIndex)>=0;
            end
            if positive && all(isfinite(xt))
                Ft = fun(xt);
                if norm(Ft,inf) < (1-1e-4*step)*residual
                    x = xt;
                    accepted = true;
                    break;
                end
            end
            step = step/2;
        end
        if ~accepted, return; end
    end
    F = fun(x);
    ok = norm(F,inf) <= tol;
end

function [st,ok] = inspect_point(v,lambda,p,net,cfg,previous)
    st = struct(); ok = false;
    [~,st.S] = fixed_power(v,lambda,net);
    [~,flag] = chol((st.S+st.S.')/2);
    if flag ~= 0
        return;
    end
    u = p.u_ref*v;
    PL = lambda*net.PL0;
    B = net.Yll-diag(PL./u.^2);
    if rcond(B) < cfg.minRcondB
        return;
    end
    Ysys = net.Yss-net.Ysl*(B\net.Yls);
    mu = sort(eig((Ysys+Ysys.')/2));
    % All sources have the same L and C: the same set of modal roots is used for stability judgment, matching, and plotting.
    st.roots = modal_roots(mu,p,previous);
    st.maxReal = max(real(st.roots));
    if st.maxReal > cfg.positiveRealTol
        return;
    end
    st.reachedOrigin = min(abs(st.roots)) <= cfg.originAbsTol;
    ok = true;
end

function row = modal_roots(mu,p,previous)
    L = p.L(1); C = p.C(1); K = p.K; Ki = p.Ki;
    row = complex(zeros(1,3*numel(mu)));
    orders = perms(1:3);
    for m = 1:numel(mu)
        r = roots([L*C,L*mu(m)+K*C, ...
                   1+K*mu(m)+Ki*K*C,Ki*(1+K*mu(m))]);
        ix = 3*m-2:3*m;
        if isempty(previous)
            [~,idx] = sortrows([real(r),imag(r)],[1,2]);
            rr = r(idx);
        else
            best = Inf; rr = r;
            for j = 1:size(orders,1)
                candidate = r(orders(j,:));
                candidate = candidate(:);
                cost = norm(candidate-previous(ix).');
                if cost < best
                    best = cost; rr = candidate;
                end
            end
        end
        row(ix) = rr.';
    end
end