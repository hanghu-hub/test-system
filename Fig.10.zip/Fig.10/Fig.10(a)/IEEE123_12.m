clear; clc;
%% ================ Step 1. System Parameters =====================
K = 1;
Kinv = eye(10)/K;    
Uref = 650;
tin1=0.002;     % Constant current time
tin2=0.02;      % Step switching time
%% ================ Step 2. Solve Yeq =====================
Y=zeros(123,123);

% R1=0.5;R2=0.4;R3=0.4;R4=0.4;
R1=0.3;R2=0.2;R3=0.2;R4=0.3;    % Line resistance
Y_R1=1/R1;Y_R2=1/R2;Y_R3=1/R3;Y_R4=1/R4;

Y(10,123)=Y_R1;Y(122,123)=Y_R1;Y(121,122)=Y_R1;Y(117,121)=Y_R1;
Y(120,122)=Y_R1;Y(118,120)=Y_R1;Y(18,118)=Y_R1;Y(118,119)=Y_R1;
Y(88,119)=Y_R1;Y(87,88)=Y_R1;Y(86,87)=Y_R1;Y(85,86)=Y_R1;
Y(84,86)=Y_R1;Y(83,84)=Y_R1;Y(82,84)=Y_R1;Y(81,82)=Y_R1;
Y(80,82)=Y_R1;Y(79,80)=Y_R1;Y(78,80)=Y_R1;Y(20,78)=Y_R1;

Y(6,99)=Y_R2;Y(97,98)=Y_R2;Y(98,99)=Y_R2;Y(96,100)=Y_R2;Y(88,91)=Y_R2;
Y(97,100)=Y_R2;Y(96,97)=Y_R2;Y(100,101)=Y_R2;Y(101,102)=Y_R2;
Y(102,103)=Y_R2;Y(103,104)=Y_R2;Y(102,105)=Y_R2;Y(105,106)=Y_R2;
Y(106,107)=Y_R2;Y(7,107)=Y_R2;Y(105,108)=Y_R2;Y(108,109)=Y_R2;
Y(110,111)=Y_R2;Y(109,110)=Y_R2;Y(72,108)=Y_R2;Y(72,73)=Y_R2;
Y(73,112)=Y_R2;Y(112,113)=Y_R2;Y(8,113)=Y_R2;Y(72,91)=Y_R2;
Y(91,114)=Y_R2;Y(114,115)=Y_R2;Y(115,116)=Y_R2;Y(9,116)=Y_R2;

Y(71,72)=Y_R3;Y(70,71)=Y_R3;Y(69,70)=Y_R3;Y(69,92)=Y_R3;
Y(92,93)=Y_R3;Y(93,94)=Y_R3;Y(94,95)=Y_R3;Y(13,95)=Y_R3;
Y(69,89)=Y_R3;Y(89,90)=Y_R3;Y(68,69)=Y_R3;Y(68,76)=Y_R3;
Y(67,68)=Y_R3;Y(17,67)=Y_R3;Y(57,74)=Y_R3;Y(74,75)=Y_R3;
Y(75,76)=Y_R3;Y(76,77)=Y_R3;Y(19,77)=Y_R3;Y(64,65)=Y_R3;
Y(65,66)=Y_R3;Y(15,66)=Y_R3;Y(45,65)=Y_R3;Y(42,45)=Y_R3;
Y(14,42)=Y_R3;Y(40,42)=Y_R3;Y(40,41)=Y_R3;Y(37,40)=Y_R3;
Y(37,38)=Y_R3;Y(38,39)=Y_R3;Y(31,37)=Y_R3;Y(30,31)=Y_R3;
Y(31,32)=Y_R3;Y(32,33)=Y_R3;Y(12,33)=Y_R3;Y(44,45)=Y_R3;

Y(1,23)=Y_R4;Y(23,24)=Y_R4;Y(21,22)=Y_R4;Y(22,24)=Y_R4;
Y(24,25)=Y_R4;Y(25,26)=Y_R4;Y(26,29)=Y_R4;Y(28,29)=Y_R4;
Y(27,28)=Y_R4;Y(11,27)=Y_R4;Y(29,34)=Y_R4;Y(2,34)=Y_R4;
Y(34,35)=Y_R4;Y(35,36)=Y_R4;Y(35,44)=Y_R4;Y(43,44)=Y_R4;
Y(16,43)=Y_R4;Y(44,57)=Y_R4;Y(57,58)=Y_R4;Y(58,59)=Y_R4;
Y(4,59)=Y_R4;Y(59,63)=Y_R4;Y(55,57)=Y_R4;Y(55,56)=Y_R4;
Y(51,55)=Y_R4;Y(48,51)=Y_R4;Y(47,48)=Y_R4;Y(46,47)=Y_R4;
Y(3,46)=Y_R4;Y(46,49)=Y_R4;Y(54,55)=Y_R4;Y(53,54)=Y_R4;
Y(50,53)=Y_R4;Y(52,53)=Y_R4;Y(53,60)=Y_R4;Y(5,60)=Y_R4;
Y(60,61)=Y_R4;Y(61,62)=Y_R4;


Y=Y+Y';
Y=diag(Y*ones(123,1))-Y;

% disp('Y=')2
% disp(Y)


%% ================ Step 3. Solve Yeq and alpha =====================

Yss=Y(1:10,1:10);Ysl=Y(1:10,11:123);Yls=Y(11:123,1:10);Yll=Y(11:123,11:123);
Yeq=Yll-Yls*(Yss+Kinv)^(-1)*Ysl;
% disp('Yeq = ');
% disp(Yeq);

Vstar = Uref * ones(10,1);
alpha = Yls * (Yss + Kinv)^(-1) * Kinv * Vstar;
% disp('alpha = ');
% disp(alpha);

%% ================ Step 4. Newton iteration method to solve UL =====================
U1=650;
tol = 1e-6;
maxIter = 100;

u = U1 * ones(113,1);
PL=[3e3*ones(10,1); 2.5e3*ones(45,1); 2.5e3*ones(25,1);3e3*ones(33,1)]; 
p = -PL;

for iter = 1:maxIter
    UL = diag(u);
    F = UL * (Yeq * u + alpha) - p;
    J = diag(Yeq * u + alpha) + UL * Yeq;
    du = -J\F;
    u = u + du;
    
    if norm(du, inf) < tol
        fprintf('Newton iteration converged in %d iterations.\n', iter);
        break;
    end
end

disp('---- Calculation Results ----');
Vin = ones(123,1);
for i = 1:113
    load_node = 10 + i;  % Load nodes 11~123
    Vin(load_node) = u(i);
    fprintf('V_CPL%d = %.4f V\n', load_node, u(i));
end