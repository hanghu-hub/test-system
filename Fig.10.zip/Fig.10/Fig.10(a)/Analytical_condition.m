Y=zeros(123,123);
Lline=zeros(123,123);

% R1=0.5;R2=0.4;R3=0.4;R4=0.4;
R1=0.3;R2=0.2;R3=0.2;R4=0.3;    %线路阻�??
LL1=1e-6   ; LL2= 5e-7 ; LL3= 5e-7; LL4= 1e-6;
Y_R1=1/R1;Y_R2=1/R2;Y_R3=1/R3;Y_R4=1/R4;

Y(10,123)=Y_R1;Lline(10,123)=LL1;Y(122,123)=Y_R1;Lline(122,123)=LL1;Y(121,122)=Y_R1;Lline(121,122)=LL1;Y(117,121)=Y_R1;Lline(117,121)=LL1;
Y(120,122)=Y_R1;Lline(120,122)=LL1;Y(118,120)=Y_R1;Lline(118,120)=LL1;Y(18,118)=Y_R1;Lline(18,118)=LL1;Y(118,119)=Y_R1;Lline(118,119)=LL1;
Y(88,119)=Y_R1;Lline(88,119)=LL1;Y(87,88)=Y_R1;Lline(87,88)=LL1;Y(86,87)=Y_R1;Lline(86,87)=LL1;Y(85,86)=Y_R1;Lline(85,86)=LL1;
Y(84,86)=Y_R1;Lline(84,86)=LL1;Y(83,84)=Y_R1;Lline(83,84)=LL1;Y(82,84)=Y_R1;Lline(82,84)=LL1;Y(81,82)=Y_R1;Lline(81,82)=LL1;
Y(80,82)=Y_R1;Lline(80,82)=LL1;Y(79,80)=Y_R1;Lline(79,80)=LL1;Y(78,80)=Y_R1;Lline(78,80)=LL1;Y(20,78)=Y_R1;Lline(20,78)=LL1;

Y(6,99)=Y_R2;Lline(6,99)=LL2;Y(97,98)=Y_R2;Lline(97,98)=LL2;Y(98,99)=Y_R2;Lline(98,99)=LL2;Y(96,100)=Y_R2;Lline(96,100)=LL2;Y(88,91)=Y_R2;Lline(88,91)=LL2;
Y(97,100)=Y_R2;Lline(97,100)=LL2;Y(96,97)=Y_R2;Lline(96,97)=LL2;Y(100,101)=Y_R2;Lline(100,101)=LL2;Y(101,102)=Y_R2;Lline(101,102)=LL2;
Y(102,103)=Y_R2;Lline(102,103)=LL2;Y(103,104)=Y_R2;Lline(103,104)=LL2;Y(102,105)=Y_R2;Lline(102,105)=LL2;Y(105,106)=Y_R2;Lline(105,106)=LL2;
Y(106,107)=Y_R2;Lline(106,107)=LL2;Y(7,107)=Y_R2;Lline(7,107)=LL2;Y(105,108)=Y_R2;Lline(105,108)=LL2;Y(108,109)=Y_R2;Lline(108,109)=LL2;
Y(110,111)=Y_R2;Lline(110,111)=LL2;Y(109,110)=Y_R2;Lline(109,110)=LL2;Y(72,108)=Y_R2;Lline(72,108)=LL2;Y(72,73)=Y_R2;Lline(72,73)=LL2;
Y(73,112)=Y_R2;Lline(73,112)=LL2;Y(112,113)=Y_R2;Lline(112,113)=LL2;Y(8,113)=Y_R2;Lline(8,113)=LL2;Y(72,91)=Y_R2;Lline(72,91)=LL2;
Y(91,114)=Y_R2;Lline(91,114)=LL2;Y(114,115)=Y_R2;Lline(114,115)=LL2;Y(115,116)=Y_R2;Lline(115,116)=LL2;Y(9,116)=Y_R2;Lline(9,116)=LL2;

Y(71,72)=Y_R3;Lline(71,72)=LL2;Y(70,71)=Y_R3;Lline(70,71)=LL3;Y(69,70)=Y_R3;Lline(69,70)=LL3;Y(69,92)=Y_R3;Lline(69,92)=LL3;
Y(92,93)=Y_R3;Lline(92,93)=LL3;Y(93,94)=Y_R3;Lline(93,94)=LL3;Y(94,95)=Y_R3;Lline(94,95)=LL3;Y(13,95)=Y_R3;Lline(13,95)=LL3;
Y(69,89)=Y_R3;Lline(69,89)=LL3;Y(89,90)=Y_R3;Lline(89,90)=LL3;Y(68,69)=Y_R3;Lline(68,69)=LL3;Y(68,76)=Y_R3;Lline(68,76)=LL3;
Y(67,68)=Y_R3;Lline(67,68)=LL3;Y(17,67)=Y_R3;Lline(17,67)=LL3;Y(57,74)=Y_R3;Lline(57,74)=LL4;Y(74,75)=Y_R3;Lline(74,75)=LL3;
Y(75,76)=Y_R3;Lline(75,76)=LL3;Y(76,77)=Y_R3;Lline(76,77)=LL3;Y(19,77)=Y_R3;Lline(19,77)=LL3;Y(64,65)=Y_R3;Lline(64,65)=LL3;
Y(65,66)=Y_R3;Lline(65,66)=LL3;Y(15,66)=Y_R3;Lline(15,66)=LL3;Y(45,65)=Y_R3;Lline(45,65)=LL3;Y(42,45)=Y_R3;Lline(42,45)=LL3;
Y(14,42)=Y_R3;Lline(14,42)=LL3;Y(40,42)=Y_R3;Lline(40,42)=LL3;Y(40,41)=Y_R3;Lline(40,41)=LL3;Y(37,40)=Y_R3;Lline(37,40)=LL3;
Y(37,38)=Y_R3;Lline(37,38)=LL3;Y(38,39)=Y_R3;Lline(38,39)=LL3;Y(31,37)=Y_R3;Lline(31,37)=LL3;Y(30,31)=Y_R3;Lline(30,31)=LL3;
Y(31,32)=Y_R3;Lline(31,32)=LL3;Y(32,33)=Y_R3;Lline(32,33)=LL3;Y(12,33)=Y_R3;Lline(12,33)=LL3;Y(44,45)=Y_R3;Lline(44,45)=LL4;

Y(1,23)=Y_R4;Lline(1,23)=LL4;Y(23,24)=Y_R4;Lline(23,24)=LL4;Y(21,22)=Y_R4;Lline(21,22)=LL4;Y(22,24)=Y_R4;Lline(22,24)=LL4;
Y(24,25)=Y_R4;Lline(24,25)=LL4;Y(25,26)=Y_R4;Lline(25,26)=LL4;Y(26,29)=Y_R4;Lline(26,29)=LL4;Y(28,29)=Y_R4;Lline(28,29)=LL4;
Y(27,28)=Y_R4;Lline(27,28)=LL4;Y(11,27)=Y_R4;Lline(11,27)=LL4;Y(29,34)=Y_R4;Lline(29,34)=LL4;Y(2,34)=Y_R4;Lline(2,34)=LL4;
Y(34,35)=Y_R4;Lline(34,35)=LL4;Y(35,36)=Y_R4;Lline(35,36)=LL4;Y(35,44)=Y_R4;Lline(35,44)=LL4;Y(43,44)=Y_R4;Lline(43,44)=LL4;
Y(16,43)=Y_R4;Lline(16,43)=LL4;Y(44,57)=Y_R4;Lline(44,57)=LL4;Y(57,58)=Y_R4;Lline(57,58)=LL4;Y(58,59)=Y_R4;Lline(58,59)=LL4;
Y(4,59)=Y_R4;Lline(4,59)=LL4;Y(59,63)=Y_R4;Lline(59,63)=LL4;Y(55,57)=Y_R4;Lline(55,57)=LL4;Y(55,56)=Y_R4;Lline(55,56)=LL4;
Y(51,55)=Y_R4;Lline(51,55)=LL4;Y(48,51)=Y_R4;Lline(48,51)=LL4;Y(47,48)=Y_R4;Lline(47,48)=LL4;Y(46,47)=Y_R4;Lline(46,47)=LL4;
Y(3,46)=Y_R4;Lline(3,46)=LL4;Y(46,49)=Y_R4;Lline(46,49)=LL4;Y(54,55)=Y_R4;Lline(54,55)=LL4;Y(53,54)=Y_R4;Lline(53,54)=LL4;
Y(50,53)=Y_R4;Lline(50,53)=LL4;Y(52,53)=Y_R4;Lline(52,53)=LL4;Y(53,60)=Y_R4;Lline(53,60)=LL4;Y(5,60)=Y_R4;Lline(5,60)=LL4;
Y(60,61)=Y_R4;Lline(60,61)=LL4;Y(61,62)=Y_R4;Lline(61,62)=LL4;

CL=(1e-4)*eye(113); C=(1e-3)*eye(10); L=(5e-4)*eye(10);K=eye(10);

A=Y+Y';LA=Lline+Lline'; %% Adjacency matrix
A1=A.*A.*LA; Gamma=diag(A1*ones(123,1)); 


eig([C-L*K^(-2) zeros(10,113);zeros(113,10) CL]-(Gamma-A1))




